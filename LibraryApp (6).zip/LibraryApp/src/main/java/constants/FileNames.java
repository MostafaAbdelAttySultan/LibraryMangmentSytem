/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package constants;

/**
 *
 * @author ADMIN
 */
public interface FileNames {
    String BOOKS_FILENAME= "Books.txt";
    String LIBRARIANS_FILENAME= "Librarians.txt ";
    String STUDENTSBOOKS_FILENAME= "StudentsBooks.txt";
}
